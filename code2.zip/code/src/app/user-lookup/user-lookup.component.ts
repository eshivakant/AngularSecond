import { Component, OnInit } from '@angular/core';
import { Service, Employee } from '../app.service'

@Component({
  selector: 'app-user-lookup',
  templateUrl: './user-lookup.component.html',
  styleUrls: ['./user-lookup.component.scss'],
  providers: [Service]
})
export class UserLookupComponent implements OnInit {
  employees: Employee[];

  constructor(service: Service) {
    this.employees = service.getEmployees();
  }

  ngOnInit() {
  }

}
