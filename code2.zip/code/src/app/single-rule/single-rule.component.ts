import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-rule',
  templateUrl: './single-rule.component.html',
  styleUrls: ['./single-rule.component.scss']
})
export class SingleRuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
