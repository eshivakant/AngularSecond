export class Employee {
    public name: string;
    public ssoId: string;
    public gfitId: string;
    public empId: string;
}