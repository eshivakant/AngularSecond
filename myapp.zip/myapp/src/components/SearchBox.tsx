import * as React from 'react';

export interface ISearchBoxProps {
    initialToken?: string;
    onChange: any;
}

export interface ISearchBoxState {
    token?: string;
}

class SearchBox extends React.Component<ISearchBoxProps, ISearchBoxState> {

    constructor(props: ISearchBoxProps) {
        super(props);

        this.state = { token: this.props.initialToken };
        this.handleChange = this.handleChange.bind(this);
    }

    public render() {
        return (
            <div>
                <input value={this.state.token} onChange={this.handleChange} />
            </div>
        );
    }

    private handleChange($event: any) {
        this.props.onChange($event);
        this.setState({ token: $event.target.value });
    }
}

export default SearchBox;
