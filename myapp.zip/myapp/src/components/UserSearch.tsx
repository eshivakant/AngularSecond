import * as React from 'react';

import EmpCard from './EmpCard';
import { Employee } from './interfaces/Employee';
import { Repository } from './services/Repository';
import SearchBox from './SearchBox';

export interface IUserSearchProps {
  initialToken?: string;
  onChange: any;
}

export interface IUserSearchState {
  token?: string;
  employees:Employee[];
}

class UserSearch extends React.Component<IUserSearchProps,IUserSearchState> {

    /**
     *
     */
    constructor(props:IUserSearchProps, state:IUserSearchState) {
        super(props);  
        this.state = { token: this.props.initialToken, employees:[] };
        this.handleSearchTokenChange = this.handleSearchTokenChange.bind(this);
        this.onSelected = this.onSelected.bind(this);
    }

  public render() {
    return (
      <div className="SearchBox">
        <SearchBox initialToken="" onChange={this.handleSearchTokenChange} />
        <div>
          This is grid filtered by {this.state.token}
          {this.state.employees.map(e=><EmpCard key={e.empId} employee={e} onClick={this.onSelected} />)}
        </div>

      </div>
     
    );
  }

  public onSelected(e:Employee){
    alert(e.name);
  }

  public handleSearchTokenChange($event:any){
    this.props.onChange($event);

    const emps = Repository.getEmployees($event.target.value);

    this.setState({token:$event.target.value, employees:emps })
  }

}

export default UserSearch;
