import { Employee } from "../interfaces/Employee";

export class Repository{

    public static getEmployees(token:string):Employee[]{
        const employees:Employee[]=[];

        employees.push({
            empId:"545878",
            gfitId:"445687",
            name:"Shivakant Upadhyay",
            ssoId:"C14680"
        });

        employees.push({
            empId:"545444",
            gfitId:"8877888",
            name:"Nigel Touch",
            ssoId:"C77680"
        });


        return employees;
    }
}