import * as React from 'react';

import { Employee } from "./interfaces/Employee";

interface IEmpCardProp{
    employee:Employee;
    onClick:any;
}

interface IEmpCardState{
    selected:boolean
}

class EmpCard extends React.Component<IEmpCardProp,IEmpCardState>{

    constructor(props:IEmpCardProp,state:IEmpCardState) {
        super(props);   
        this.state={selected:false};
        this.onClick = this.onClick.bind(this);
    }

    public render() {
        return (
            <div onClick = {this.onClick}>
                <div>{this.props.employee.name}</div>
                <div>{this.props.employee.ssoId}</div>
                <div>{this.props.employee.gfitId}</div>
                <div>{this.props.employee.empId}</div>                
            </div>
        )
    }

    
    public onClick($event:any){
       
		this.props.onClick(this.props.employee);
        this.setState({ selected:true });
        
       
    }

}

export default EmpCard;