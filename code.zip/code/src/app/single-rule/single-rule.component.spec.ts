import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleRuleComponent } from './single-rule.component';

describe('SingleRuleComponent', () => {
  let component: SingleRuleComponent;
  let fixture: ComponentFixture<SingleRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
