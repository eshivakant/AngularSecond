import { Component, OnInit } from '@angular/core';
import {MatChipInputEvent} from '@angular/material';
import {ENTER, COMMA} from '@angular/cdk/keycodes';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-rule-configuration',
  templateUrl: './rule-configuration.component.html',
  styleUrls: ['./rule-configuration.component.scss']
})
export class RuleConfigurationComponent implements OnInit {

  panelOpenState: boolean = false;

  visible: boolean = true;
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;

  cortexFormGroup: FormGroup;
  centricFormGroup: FormGroup;

  xTradeFormGroup: FormGroup;
  xDealFormGroup: FormGroup;
  xOrderFormGroup: FormGroup;
  xMiscFormGroup: FormGroup;
  
  cTradeFormGroup: FormGroup;
  cDealFormGroup: FormGroup;
  cOrderFormGroup: FormGroup;
  cMiscFormGroup: FormGroup;
  
  constructor(private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.cortexFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.centricFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });


    this.xTradeFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.xDealFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.xOrderFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.xMiscFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });


    this.cTradeFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.cDealFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.cOrderFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.cMiscFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

    // Enter, comma
    separatorKeysCodes = [ENTER, COMMA];

    additionalRecipients = [
      { address: 'shivakant@outlook.com' },
      { address: '07594956052' }      
    ];
  
  
    add(event: MatChipInputEvent): void {
      let input = event.input;
      let value = event.value;
  
      if ((value || '').trim()) {
        this.additionalRecipients.push({ address: value.trim() });
      }
  
      // Reset the input value
      if (input) {
        input.value = '';
      }
    }
  
    remove(email: any): void {
      let index = this.additionalRecipients.indexOf(email);
  
      if (index >= 0) {
        this.additionalRecipients.splice(index, 1);
      }
    }

}
